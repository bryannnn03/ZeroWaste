import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../config/app_config.dart';

/// Holds one extracted food item from a receipt.
class ExtractedItem {
  String name;
  double quantity;
  String unit;
  String category;
  DateTime expiryDate;

  ExtractedItem({
    required this.name,
    required this.quantity,
    required this.unit,
    required this.category,
    required this.expiryDate,
  });

  factory ExtractedItem.fromJson(Map<String, dynamic> json) {
    final expiryDays = (json['estimated_expiry_days'] as num?)?.toInt() ?? 7;
    final rawName = (json['name'] as String?)?.trim() ?? 'Unknown Item';
    final rawUnit = (json['unit'] as String?)?.trim() ?? '';
    return ExtractedItem(
      name: _cleanItemName(rawName),
      quantity: (json['quantity'] as num?)?.toDouble() ?? 1.0,
      unit: _normaliseUnit(rawUnit, rawName),
      category: (json['category'] as String?)?.trim() ?? 'Other',
      expiryDate: DateTime.now().add(Duration(days: expiryDays)),
    );
  }
}

// ── Name cleaner ──────────────────────────────────────────────────────────────
/// Cleans up common Malaysian receipt OCR naming issues.
/// e.g. "Ayam Ikan Mackeral" → "Ayam Brand Ikan Makarel Sardin"
///      "GDN WHT BRD" → "Gardenia White Bread"
String _cleanItemName(String raw) {
  // Expand known Malaysian brand abbreviations from receipts
  final brandExpansions = <String, String>{
    r'\bAYAM\b(?!\s+BRAND)': 'Ayam Brand',
    r'\bGDN\b': 'Gardenia',
    r'\bGARDENIA\b': 'Gardenia',
    r'\bMAGGI\b': 'Maggi',
    r'\bNESCAFE\b': 'Nescafe',
    r'\bMILO\b': 'Milo',
    r'\bF&N\b': 'F&N',
    r'\bHL\b(?=\s)': 'HL',
    r'\bDUTCH\s*LADY\b': 'Dutch Lady',
    r'\bKIKKOMAN\b': 'Kikkoman',
    r'\bLEA\s*&?\s*PERRINS\b': 'Lea & Perrins',
  };

  String name = raw;
  brandExpansions.forEach((pattern, replacement) {
    name = name.replaceAllMapped(
      RegExp(pattern, caseSensitive: false),
      (_) => replacement,
    );
  });

  // Title-case the result cleanly
  name = name
      .split(' ')
      .map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1).toLowerCase())
      .join(' ');

  // Re-uppercase known all-caps brand tokens after title-casing
  const preserveUppercase = ['F&N', 'HL', 'UHT', 'UTH'];
  for (final token in preserveUppercase) {
    name = name.replaceAll(
      RegExp(RegExp.escape(token), caseSensitive: false),
      token,
    );
  }

  return name.trim();
}

// ── Unit normaliser ───────────────────────────────────────────────────────────
/// Normalises raw unit string, using item name as fallback context.
String _normaliseUnit(String raw, String itemName) {
  final u = raw.toLowerCase().trim();
  final n = itemName.toLowerCase();

  // ── Explicit unit from model ──────────────────────────────────────────────
  if (u == 'g' || u == 'gram' || u == 'grams')             return 'g';
  if (u == 'kg' || u == 'kilogram' || u == 'kilograms')    return 'kg';
  if (u == 'ml' || u == 'milliliter' || u == 'millilitre') return 'ml';
  if (u == 'l' || u == 'liter' || u == 'litre')            return 'L';
  if (u == 'loaf' || u == 'loaves')                        return 'loaf';
  if (u == 'tin' || u == 'can' || u == 'cans' || u == 'tins') return 'tin';
  if (u == 'packet' || u == 'pack' || u == 'packets' || u == 'packs') return 'packet';
  if (u == 'bottle' || u == 'bottles')                     return 'bottle';
  if (u == 'box' || u == 'boxes')                          return 'box';
  if (u == 'bag' || u == 'bags')                           return 'bag';
  if (u == 'bunch' || u == 'bunches')                      return 'bunch';
  if (u == 'tray' || u == 'trays')                         return 'tray';
  if (u == 'roll' || u == 'rolls')                         return 'roll';
  if (u == 'sachet' || u == 'sachets')                     return 'sachet';
  if (u == 'pcs' || u == 'pc' || u == 'piece' || u == 'pieces') {
    if (_nameImpliesPcs(n)) return 'pcs';
  }

  // ── Name-based inference ──────────────────────────────────────────────────
  if (_contains(n, ['bread', 'gardenia', 'massimo', 'loaf', 'wholemeal', 'roti sandwich'])) return 'loaf';
  if (_contains(n, ['ayam brand', 'tuna', 'sardine', 'sardin', 'mackerel', 'makarel',
      'baked beans', 'cream of mushroom', 'campbell', 'braised', 'corned beef',
      'luncheon meat', 'spam', 'condensed milk', 'evaporated milk', 'coconut milk tin'])) return 'tin';
  if (_contains(n, ['sauce', 'kicap', 'soy sauce', 'oyster sauce', 'chilli sauce',
      'tomato sauce', 'vinegar', 'oil', 'minyak', 'cordial', 'sunquick', 'ribena',
      'mineral water', 'air mineral', 'juice', 'jus', 'f&n', 'season', 'worcestershire',
      'lea & perrins', 'fish sauce', 'sos'])) return 'bottle';
  if (_contains(n, ['maggi', 'instant noodle', 'mee segera', 'mamee', 'biscuit', 'biskut',
      'chips', 'crisp', 'keropok', 'cracker', 'snack', 'kuih', 'kacang',
      'seasoning', 'perencah', 'curry powder', 'serbuk kari', 'rempah',
      'sugar sachet', 'oats', 'milo packet', 'tea bag', 'teh tarik',
      'nestum', 'quaker', 'cereal packet'])) return 'packet';
  if (_contains(n, ['cereal', 'cornflakes', 'kellogg', 'nestum box', 'tissue',
      'tea box', 'milk box', 'uht', 'dutch lady box', 'hl milk'])) return 'box';
  if (_contains(n, ['beras', 'rice', 'flour', 'tepung', 'sugar', 'gula',
      'salt', 'garam', 'frozen', 'beku', 'peas', 'mixed veg'])) return 'bag';
  if (_contains(n, ['chicken', 'ayam', 'beef', 'daging', 'lamb', 'mutton',
      'fish', 'ikan', 'prawn', 'udang', 'sotong', 'squid',
      'minced', 'fillet', 'drumstick', 'wing', 'thigh'])) return 'g';
  if (_contains(n, ['banana', 'pisang', 'grape', 'anggur', 'spring onion',
      'daun bawang', 'coriander', 'cilantro', 'daun ketumbar',
      'kangkung', 'spinach', 'bayam'])) return 'bunch';
  if (_contains(n, ['apple', 'epal', 'orange', 'limau', 'pear', 'egg', 'telur',
      'tomato', 'potato', 'kentang', 'onion', 'bawang', 'garlic', 'bawang putih',
      'carrot', 'lobak', 'corn', 'jagung', 'lemon', 'lime'])) return 'pcs';
  if (_contains(n, ['milk', 'susu', 'yogurt', 'yoghurt'])) return 'bottle';

  return u.isEmpty || u == 'pcs' ? 'pcs' : raw.trim();
}

bool _contains(String name, List<String> keywords) =>
    keywords.any((k) => name.contains(k));

bool _nameImpliesPcs(String name) =>
    _contains(name, ['egg', 'telur', 'apple', 'epal', 'orange', 'limau',
        'pear', 'onion', 'bawang', 'potato', 'kentang', 'corn', 'jagung',
        'lemon', 'lime', 'tomato', 'garlic']);

// ── OCR Service ───────────────────────────────────────────────────────────────

/// Model descriptor used for the fallback chain.
class _Model {
  final String id;
  final String label;
  const _Model(this.id, this.label);
}

class ReceiptOcrService {
  static const _endpoint = 'https://openrouter.ai/api/v1/chat/completions';

  /// Primary model → fallback models, tried in order.
  /// All are free-tier vision-capable models on OpenRouter.
  static const _models = [
    _Model('openrouter/auto',                         'OpenRouter Auto'),
    _Model('qwen/qwen2.5-vl-72b-instruct:free',       'Qwen 2.5 VL 72B'),
    _Model('meta-llama/llama-3.2-11b-vision-instruct:free', 'Llama 3.2 11B Vision'),
  ];

  static const _prompt = r'''
You are a grocery receipt parser specialised in Malaysian supermarket receipts (e.g. Giant, Tesco, Lotus's, Mydin, Jaya Grocer, Village Grocer, AEON, 99 Speedmart).

Extract every food or grocery item from this receipt image.
Return ONLY a raw JSON array — no markdown, no explanation, no code fences.

Each element must follow this EXACT shape:
{
  "name": "Clean readable product name",
  "quantity": 1,
  "unit": "loaf",
  "category": "Bakery",
  "estimated_expiry_days": 4
}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULE 1 — ITEM NAMES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Expand abbreviations and clean up OCR artifacts into proper readable names.
- "AYAM IKN MCK" → "Ayam Brand Ikan Makarel Sardin"
- "GDN WHT BRD 400G" → "Gardenia White Bread"
- "MLO ACTGEN 400G" → "Milo Activ-Go"
- "MGGI CKN NDL" → "Maggi Ayam Noodles"
- "HL FULL CRM 1L" → "HL Full Cream Milk 1L"
If a brand name appears without "Brand" (e.g. "AYAM"), write it as "Ayam Brand".
Always write names in Title Case.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULE 2 — UNITS (CRITICAL — never default to pcs)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Infer the correct unit from the product name and packaging type.
NEVER return "pcs" unless the item is a loose countable item (eggs, apples, oranges).

Unit → when to use:
  loaf    → any bread sold as a loaf (Gardenia, Massimo, wholemeal bread)
  tin     → canned goods (Ayam Brand, tuna, sardines, baked beans, condensed milk, luncheon meat)
  packet  → sealed packets (Maggi noodles, biscuits, chips, seasoning, curry powder, oats)
  bottle  → bottles (sauces, cordials, mineral water, juice, cooking oil, soy sauce, milk in bottle)
  box     → boxes (cereal, UHT milk box, tissue, tea bags)
  bag     → bags (rice, flour, sugar, frozen vegetables, salt)
  g       → fresh items sold by weight (chicken, beef, fish, prawns, minced meat)
  kg      → bulk weight items (large bags of rice, potatoes by weight)
  ml      → small liquid volumes
  L       → large liquid volumes (1L, 1.5L bottles — but use "bottle" as unit, not L)
  bunch   → produce sold in bunches (bananas, kangkung, spring onions, grapes)
  tray    → eggs sold on a tray (10pcs tray, 30pcs tray)
  pcs     → ONLY for loose single items (1 apple, 1 orange, 1 egg)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULE 3 — EXPIRY DAYS (Malaysia-specific)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Use Malaysian shelf-life defaults — NOT European or US defaults.
Malaysia has a hot and humid climate. Shelf life is shorter than Western countries.

Category defaults:
  Fresh meat / poultry (chicken, beef, lamb)  → 2 days
  Fresh seafood (fish, prawns, squid)          → 1 day
  Fresh vegetables (leafy greens, kangkung)   → 3 days
  Fresh vegetables (root veg, tomatoes)        → 5 days
  Fresh fruits (bananas, papayas)              → 3 days
  Fresh fruits (apples, oranges, imported)     → 7 days
  Eggs                                         → 14 days
  Fresh bread / Gardenia / Massimo loaf        → 4 days
  Bakery / pastry (non-packaged)               → 2 days
  Fresh dairy (milk, yogurt, fresh cheese)     → 5 days
  UHT milk (unopened)                          → 180 days
  Tofu / tauhu                                 → 2 days
  Chilled processed meat (luncheon, sausage)   → 7 days
  Frozen items (unopened)                      → 90 days
  Instant noodles / biscuits / snacks          → 180 days
  Canned goods (sardines, tuna, baked beans)   → 730 days
  Cooking oil / sauces (unopened)              → 365 days
  Rice / flour / sugar (unopened)              → 365 days
  Beverages (juice, cordial, mineral water)    → 365 days

Brand-specific overrides (use these EXACTLY):
  Gardenia / Massimo bread → 4 days
  Chilled tofu (tauhu)     → 2 days
  Fresh coconut milk       → 2 days

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULE 4 — CATEGORIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Must be exactly one of: Produce, Dairy, Meat, Seafood, Bakery, Frozen, Beverages, Pantry, Snacks, Other.
- Canned goods → Pantry
- Sauces, cooking oil, rice, flour → Pantry
- Instant noodles, biscuits, chips → Snacks
- Fresh chicken / beef / lamb → Meat
- Fresh fish / prawns / squid → Seafood

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULE 5 — WHAT TO SKIP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Skip: non-food items (soap, detergent, batteries, shampoo), receipt metadata (subtotal, tax, GST, SST, total, store name, cashier name, date, receipt number).
''';

  /// Attempts to call one model. Returns the parsed item list on success,
  /// or throws a [_OcrModelException] on a retryable model-level failure,
  /// or rethrows any non-retryable error.
  static Future<List<ExtractedItem>> _callModel(
    _Model model,
    String base64Image,
    String mime,
  ) async {
    final response = await http
        .post(
          Uri.parse(_endpoint),
          headers: {
            'Authorization': 'Bearer ${AppConfig.openRouterApiKey}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': model.id,
            // Raised from 1500 → 3000 to handle long receipts without truncation
            'max_tokens': 3000,
            'messages': [
              {
                'role': 'user',
                'content': [
                  {'type': 'text', 'text': _prompt},
                  {
                    'type': 'image_url',
                    'image_url': {'url': 'data:$mime;base64,$base64Image'},
                  },
                ],
              }
            ],
          }),
        )
        .timeout(
          const Duration(seconds: 45),
          onTimeout: () => throw _OcrModelException(
              '${model.label} timed out after 45 s'),
        );

    // Rate-limited or server error → try next model
    if (response.statusCode == 429 || response.statusCode >= 500) {
      throw _OcrModelException(
          '${model.label} returned ${response.statusCode}');
    }

    // Auth error → no point retrying other models with the same key
    if (response.statusCode == 401) {
      throw Exception(
          'Invalid OpenRouter API key. Please check your key in app_config.dart.');
    }

    if (response.statusCode != 200) {
      final err = jsonDecode(response.body);
      final msg =
          err['error']?['message'] ?? 'Unknown error (${response.statusCode})';
      // Model-specific errors (e.g. context length, model not found) → try next
      throw _OcrModelException('${model.label}: $msg');
    }

    final data = jsonDecode(response.body);
    final content = data['choices'][0]['message']['content'] as String;

    final cleaned = content
        .replaceAll(RegExp(r'```json\s*'), '')
        .replaceAll(RegExp(r'```\s*'), '')
        .trim();

    // Some models wrap the array in an object — unwrap if needed
    dynamic raw;
    try {
      raw = jsonDecode(cleaned);
    } catch (_) {
      throw _OcrModelException('${model.label} returned unparseable JSON');
    }

    List<dynamic> jsonList;
    if (raw is List) {
      jsonList = raw;
    } else if (raw is Map && raw.containsKey('items')) {
      jsonList = raw['items'] as List<dynamic>;
    } else {
      throw _OcrModelException(
          '${model.label} returned unexpected JSON shape');
    }

    return jsonList
        .map((e) => ExtractedItem.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Scans a receipt image and returns extracted food items.
  ///
  /// Tries each model in [_models] in order. Falls back to the next model
  /// on rate-limits, timeouts, server errors, or bad JSON. Only throws
  /// if ALL models fail.
  static Future<List<ExtractedItem>> extractItems(XFile image) async {
    final bytes = await image.readAsBytes();
    final base64Image = base64Encode(bytes);
    final ext = image.name.split('.').last.toLowerCase();
    final mime = ext == 'png' ? 'image/png' : 'image/jpeg';

    _OcrModelException? lastError;

    for (final model in _models) {
      try {
        final items = await _callModel(model, base64Image, mime);
        return items; // ✅ success
      } on _OcrModelException catch (e) {
        lastError = e;
        // Log and continue to next model
        // ignore: avoid_print
        print('[ReceiptOCR] ${e.message} — trying next model…');
        continue;
      }
      // Non-retryable exceptions (401, unexpected errors) bubble up immediately
    }

    // All models exhausted
    throw Exception(
      'All OCR models failed. Last error: ${lastError?.message ?? "unknown"}. '
      'Please check your internet connection and try again.',
    );
  }
}

/// Internal exception used to signal that a model attempt failed
/// in a way that warrants trying the next model.
class _OcrModelException implements Exception {
  final String message;
  const _OcrModelException(this.message);
}