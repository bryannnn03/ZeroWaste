/// App-wide configuration.
/// ⚠️  Do NOT commit this file to a public repository.
class AppConfig {
  AppConfig._();

  /// OpenRouter API key – get yours free at https://openrouter.ai/keys
  static const String openRouterApiKey = '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';
}
