import 'package:flutter/material.dart';
import '../models/food_item.dart';
import '../theme/app_theme.dart';

class StatusBadge extends StatelessWidget {
  final UrgencyLevel urgency;
  final int? daysLeft;
  final bool showDays;

  const StatusBadge({
    super.key,
    required this.urgency,
    this.daysLeft,
    this.showDays = false,
  });

  @override
  Widget build(BuildContext context) {
    if (showDays && daysLeft != null) {
      return _buildDaysBadge();
    }
    return _buildTextBadge();
  }

  Widget _buildDaysBadge() {
    final dayLabel = daysLeft == 1 ? '1 DAY' : '$daysLeft DAYS';
    Color bgColor;
    switch (urgency) {
      case UrgencyLevel.urgent:
        bgColor = AppColors.urgentRed;
      case UrgencyLevel.soon:
        bgColor = AppColors.soonOrange;
      case UrgencyLevel.ok:
        bgColor = AppColors.yellowMedium;
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(100),
      ),
      child: Text(
        dayLabel,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: Colors.white,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildTextBadge() {
    if (urgency == UrgencyLevel.ok) return SizedBox.shrink();

    String label;
    Color textColor;
    Color bgColor;
    Color borderColor;

    if (urgency == UrgencyLevel.urgent) {
      label = 'URGENT';
      textColor = AppColors.urgentRed;
      bgColor = AppColors.urgentRed.withOpacity(0.1);
      borderColor = AppColors.urgentRed.withOpacity(0.2);
    } else {
      label = 'SOON';
      textColor = AppColors.soonOrange;
      bgColor = AppColors.soonOrange.withOpacity(0.1);
      borderColor = AppColors.soonOrange.withOpacity(0.2);
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(100),
        border: Border.all(color: borderColor),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: textColor,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
