import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_theme.dart';
import '../models/food_item.dart';
import 'status_badge.dart';
import 'animated_card_wrapper.dart';

class ExpiringItemCard extends StatelessWidget {
  final FoodItem item;
  final VoidCallback? onTap;

  const ExpiringItemCard({super.key, required this.item, this.onTap});

  Color get _borderColor {
    switch (item.urgency) {
      case UrgencyLevel.urgent:
        return AppColors.urgentRed;
      case UrgencyLevel.soon:
        return AppColors.soonOrange;
      case UrgencyLevel.ok:
        return AppColors.border;
    }
  }

  Color get _bgTint {
    switch (item.urgency) {
      case UrgencyLevel.urgent:
        return AppColors.urgentRedBg;
      case UrgencyLevel.soon:
        return AppColors.soonOrangeBg.withOpacity(0.35);
      case UrgencyLevel.ok:
        return Colors.white;
    }
  }

  Color get _accentColor {
    switch (item.urgency) {
      case UrgencyLevel.urgent:
        return AppColors.urgentRed;
      case UrgencyLevel.soon:
        return AppColors.soonOrange;
      case UrgencyLevel.ok:
        return AppColors.mutedForeground;
    }
  }

  @override
  Widget build(BuildContext context) {
    final expiryLabel = item.daysUntilExpiry == 0
        ? 'Expires today!'
        : item.daysUntilExpiry == 1
            ? 'Expires in 1 day'
            : 'Expires in ${item.daysUntilExpiry} days';

    return AnimatedCardWrapper(
      onTap: onTap,
      borderRadius: 12,
      child: Container(
        decoration: BoxDecoration(
          color: _bgTint,
          border: Border.all(color: AppColors.border.withOpacity(0.4)),
        ),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Left accent bar (4px)
              Container(width: 4, color: _borderColor),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Name & Details
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              item.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: AppColors.foreground,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const Icon(LucideIcons.tag, size: 12, color: AppColors.mutedForeground),
                                const SizedBox(width: 4),
                                Text(
                                  item.category,
                                  style: const TextStyle(fontSize: 12, color: AppColors.mutedForeground),
                                ),
                                const SizedBox(width: 12),
                                const Icon(LucideIcons.package, size: 12, color: AppColors.mutedForeground),
                                const SizedBox(width: 4),
                                Text(
                                  item.quantityDisplay,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: _accentColor,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            // Days until expiry pill
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: _accentColor.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(100),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(LucideIcons.clock, size: 10, color: _accentColor),
                                  const SizedBox(width: 4),
                                  Text(
                                    expiryLabel,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: _accentColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      StatusBadge(urgency: item.urgency),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}