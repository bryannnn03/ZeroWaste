import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/food_item.dart';
import '../theme/app_theme.dart';
import 'status_badge.dart';
import 'animated_card_wrapper.dart';

class UrgencyItemCard extends StatelessWidget {
  final FoodItem item;
  final VoidCallback? onTap;

  const UrgencyItemCard({super.key, required this.item, this.onTap});

  Color get _borderColor {
    switch (item.urgency) {
      case UrgencyLevel.urgent:
        return AppColors.urgentRed;
      case UrgencyLevel.soon:
        return AppColors.soonOrange;
      case UrgencyLevel.ok:
        return AppColors.yellowMedium;
    }
  }

  Color get _bgTint {
    switch (item.urgency) {
      case UrgencyLevel.urgent:
        return AppColors.urgentRedBg.withValues(alpha: 0.4);
      case UrgencyLevel.soon:
        return AppColors.soonOrangeBg.withValues(alpha: 0.4);
      case UrgencyLevel.ok:
        return AppColors.yellowMediumBg.withValues(alpha: 0.4);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedCardWrapper(
      onTap: onTap,
      borderRadius: 12,
      child: Container(
        decoration: BoxDecoration(
          color: _bgTint,
          border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
        ),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Colored left accent bar
              Container(width: 4, color: _borderColor),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.name,
                                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.foreground)),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    const Icon(LucideIcons.package, size: 13, color: AppColors.mutedForeground),
                                    const SizedBox(width: 6),
                                    Text(item.category,
                                        style: const TextStyle(fontSize: 14, color: AppColors.mutedForeground)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          StatusBadge(urgency: item.urgency, daysLeft: item.daysUntilExpiry, showDays: true),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Divider(height: 1, color: Colors.black.withValues(alpha: 0.05)),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('QUANTITY',
                                    style: TextStyle(
                                        fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.mutedForeground, letterSpacing: 0.8)),
                                const SizedBox(height: 4),
                                Text(item.quantityDisplay,
                                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.foreground)),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    const Icon(LucideIcons.calendarDays, size: 12, color: AppColors.mutedForeground),
                                    const SizedBox(width: 4),
                                    const Text('EXPIRES',
                                        style: TextStyle(
                                            fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.mutedForeground, letterSpacing: 0.8)),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(item.expiresOn,
                                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.foreground)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}