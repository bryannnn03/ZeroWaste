import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme/app_theme.dart';
import '../services/notification_service.dart';
import '../supabase_client.dart';
import 'home_screen.dart';
import 'inventory_screen.dart';
import 'scan_screen.dart';
import 'meals_screen.dart';
import 'notifications_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  int _mealsRefreshKey = 0;
  int _inventoryRefreshKey = 0;
  int _homeRefreshKey = 0;
  int _unreadCount = 0;

  @override
  void initState() {
    super.initState();
    _runNotificationCheck();
  }

  // ── Generate expiry notifications then refresh badge count ───────────────
  Future<void> _runNotificationCheck() async {
    await NotificationService.instance.checkAndNotify();
    await _refreshUnreadCount();

    // Listen for real-time notification changes to keep the badge updated
    supabase
        .channel('public:notifications')
        .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'notifications',
            callback: (payload) {
              _refreshUnreadCount();
            })
        .subscribe();
  }

  Future<void> _refreshUnreadCount() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) return;

      final result = await supabase
          .from('notifications')
          .select('id')
          .eq('read', false)
          .eq('user_id', userId);

      if (mounted) {
        setState(() => _unreadCount = (result as List).length);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    supabase.channel('public:notifications').unsubscribe();
    super.dispose();
  }

  void _goToInventory() => setState(() => _currentIndex = 1);
  void _goToScan()      => setState(() => _currentIndex = 2);
  void _goToMeals()     => setState(() {
    _currentIndex = 3;
    _mealsRefreshKey++;
  });

  void _refreshData() => setState(() {
    _homeRefreshKey++;
    _inventoryRefreshKey++;
  });

  // Called when user taps the Alerts tab — clear badge after short delay
  void _onTabTapped(int index) {
    setState(() => _currentIndex = index);
    if (index == 4) {
      // Refresh unread count after user views notifications
      Future.delayed(const Duration(seconds: 2), _refreshUnreadCount);
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);

    final screens = [
      HomeScreen(key: ValueKey(_homeRefreshKey), onGoToInventory: _goToInventory, onGoToScan: _goToScan, onGoToMeals: _goToMeals),
      InventoryScreen(key: ValueKey(_inventoryRefreshKey)),
      const ScanScreen(),
      MealsScreen(key: ValueKey(_mealsRefreshKey), onItemsConsumed: _refreshData),
      const NotificationsScreen(),
    ];

    return Scaffold(
      body: Stack(
        children: List.generate(screens.length, (i) {
          return Offstage(
            offstage: _currentIndex != i,
            child: screens[i],
          );
        }),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
          border: Border(
            top: BorderSide(
              color: AppColors.border.withOpacity(0.5),
              width: 1,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: _onTabTapped,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          selectedItemColor: AppColors.brandGreen,
          unselectedItemColor: const Color(0xFF9CA3AF),
          selectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
          unselectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
          iconSize: 22,
          items: [
            const BottomNavigationBarItem(icon: Icon(LucideIcons.home),    label: 'Home'),
            const BottomNavigationBarItem(icon: Icon(LucideIcons.package), label: 'Inventory'),
            const BottomNavigationBarItem(icon: Icon(LucideIcons.scan),    label: 'Scan'),
            const BottomNavigationBarItem(icon: Icon(LucideIcons.utensils),label: 'Meals'),
            BottomNavigationBarItem(
              label: 'Alerts',
              icon: _unreadCount > 0
                  ? Badge(
                      label: Text(
                        _unreadCount > 99 ? '99+' : '$_unreadCount',
                        style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700),
                      ),
                      backgroundColor: AppColors.urgentRed,
                      child: const Icon(LucideIcons.bell),
                    )
                  : const Icon(LucideIcons.bell),
            ),
          ],
        ),
      ),
    );
  }
}