import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../theme/app_theme.dart';
import '../services/receipt_ocr_service.dart';
import '../supabase_client.dart';

class ReceiptReviewScreen extends StatefulWidget {
  final List<ExtractedItem> items;
  const ReceiptReviewScreen({super.key, required this.items});

  @override
  State<ReceiptReviewScreen> createState() => _ReceiptReviewScreenState();
}

class _ReceiptReviewScreenState extends State<ReceiptReviewScreen> {
  late List<ExtractedItem> _items;
  bool _saving = false;

  static const _categories = [
    'Produce', 'Dairy', 'Meat', 'Seafood',
    'Bakery', 'Frozen', 'Beverages', 'Pantry', 'Snacks', 'Other',
  ];

  @override
  void initState() {
    super.initState();
    _items = List<ExtractedItem>.from(widget.items);
  }

  Future<void> _saveAll() async {
    if (_items.isEmpty) return;
    setState(() => _saving = true);

    try {
      final userId = supabase.auth.currentUser?.id;

      // 1. Create a receipt record first so inventory items have a traceable source.
      final receiptInsert = await supabase
          .from('receipts')
          .insert({'user_id': userId})
          .select('id')
          .single();
      final receiptId = receiptInsert['id'] as String?;

      // 2. Build inventory rows with the receipt foreign key.
      final rows = _items.map((item) {
        final expiryStr =
            '${item.expiryDate.year}-${item.expiryDate.month.toString().padLeft(2, '0')}-${item.expiryDate.day.toString().padLeft(2, '0')}';
        return {
          'user_id': userId,
          'receipt_id': receiptId,
          'name': item.name,
          'category': item.category,
          'quantity': item.quantity.round(),
          'unit': item.unit,
          'expiry_date': expiryStr,
        };
      }).toList();

      await supabase.from('inventory').insert(rows);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: [
            const Icon(LucideIcons.checkCircle, size: 16, color: Colors.white),
            const SizedBox(width: 8),
            Text('${_items.length} item${_items.length == 1 ? '' : 's'} added to inventory!'),
          ]),
          backgroundColor: AppColors.brandGreen,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
      // Pop back past scan screen to home
      Navigator.of(context).popUntil((route) => route.isFirst);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(children: [
              const Icon(LucideIcons.alertCircle, size: 16, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(child: Text('Failed to save: $e')),
            ]),
            backgroundColor: AppColors.urgentRed,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _pickDate(int index) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _items[index].expiryDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: ColorScheme.light(primary: AppColors.brandGreen),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _items[index].expiryDate = picked);
    }
  }

  void _deleteItem(int index) {
    setState(() => _items.removeAt(index));
  }

  void _addBlankItem() {
    setState(() {
      _items.add(ExtractedItem(
        name: '',
        quantity: 1,
        unit: 'pcs',
        category: 'Other',
        expiryDate: DateTime.now().add(const Duration(days: 7)),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.pageBg,
      body: Column(
        children: [
          // ── Header ──────────────────────────────────────────────────────
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(color: AppColors.brandGreen),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Positioned(
                      left: 0,
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 36, height: 36,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(LucideIcons.chevronLeft,
                              size: 18, color: Colors.white),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        const SizedBox(height: 8),
                        Container(
                          width: 64, height: 64,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.12),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: const Icon(LucideIcons.clipboardList,
                              size: 28, color: AppColors.brandGreen),
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'Review Items',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: -0.3),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Edit details before adding to inventory',
                          style: TextStyle(
                              fontSize: 13,
                              color: Colors.white.withOpacity(0.75)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Item count badge ─────────────────────────────────────────────
          Transform.translate(
            offset: const Offset(0, -14),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(100),
                border: Border.all(color: AppColors.border.withOpacity(0.5)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(LucideIcons.package, size: 14, color: AppColors.brandGreen),
                  const SizedBox(width: 6),
                  Text(
                    '${_items.length} item${_items.length == 1 ? '' : 's'} found',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.foreground,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Items list ───────────────────────────────────────────────────
          Expanded(
            child: _items.isEmpty
                ? _buildEmpty()
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: _items.length,
                    itemBuilder: (ctx, i) => _ItemCard(
                      item: _items[i],
                      index: i,
                      categories: _categories,
                      onDelete: () => _deleteItem(i),
                      onPickDate: () => _pickDate(i),
                      onCategoryChanged: (cat) =>
                          setState(() => _items[i].category = cat),
                      onNameChanged: (v) => _items[i].name = v,
                      onQuantityChanged: (v) {
                        final n = double.tryParse(v);
                        if (n != null) _items[i].quantity = n;
                      },
                      onUnitChanged: (v) => _items[i].unit = v,
                    ),
                  ),
          ),

          // ── Bottom bar ───────────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: AppColors.border.withOpacity(0.4))),
            ),
            child: Row(
              children: [
                // Add item button
                OutlinedButton(
                  onPressed: _addBlankItem,
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    side: BorderSide(color: AppColors.brandGreen.withOpacity(0.5)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Row(
                    children: [
                      Icon(LucideIcons.plus, size: 16, color: AppColors.brandGreen),
                      const SizedBox(width: 6),
                      Text('Add',
                          style: TextStyle(color: AppColors.brandGreen, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                // Save button
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: ElevatedButton(
                      onPressed: (_saving || _items.isEmpty) ? null : _saveAll,
                      child: _saving
                          ? const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(LucideIcons.checkCircle,
                                    size: 16, color: Colors.white),
                                const SizedBox(width: 8),
                                const Text('Add to Inventory'),
                              ],
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(LucideIcons.packageOpen, size: 48, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text('No items — tap + to add manually',
              style: TextStyle(color: AppColors.mutedForeground, fontSize: 14)),
        ],
      ),
    );
  }
}

// ── Item card ────────────────────────────────────────────────────────────────

class _ItemCard extends StatelessWidget {
  final ExtractedItem item;
  final int index;
  final List<String> categories;
  final VoidCallback onDelete;
  final VoidCallback onPickDate;
  final ValueChanged<String> onCategoryChanged;
  final ValueChanged<String> onNameChanged;
  final ValueChanged<String> onQuantityChanged;
  final ValueChanged<String> onUnitChanged;

  const _ItemCard({
    required this.item,
    required this.index,
    required this.categories,
    required this.onDelete,
    required this.onPickDate,
    required this.onCategoryChanged,
    required this.onNameChanged,
    required this.onQuantityChanged,
    required this.onUnitChanged,
  });

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Row 1: index badge + name field + delete
            Row(
              children: [
                Container(
                  width: 26, height: 26,
                  decoration: BoxDecoration(
                    color: AppColors.mintBg,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text('${index + 1}',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: AppColors.brandGreen)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    initialValue: item.name,
                    onChanged: onNameChanged,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600),
                    decoration: InputDecoration(
                      hintText: 'Item name',
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: onDelete,
                  child: Container(
                    width: 30, height: 30,
                    decoration: BoxDecoration(
                      color: AppColors.urgentRedBg,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(LucideIcons.trash2,
                        size: 14, color: AppColors.urgentRed),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Row 2: qty + unit + category
            Row(
              children: [
                // Quantity
                SizedBox(
                  width: 64,
                  child: TextFormField(
                    initialValue: item.quantity % 1 == 0
                        ? item.quantity.toInt().toString()
                        : item.quantity.toString(),
                    onChanged: onQuantityChanged,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 13),
                    decoration: InputDecoration(
                      labelText: 'Qty',
                      labelStyle: TextStyle(
                          fontSize: 11, color: AppColors.mutedForeground),
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // Unit
                SizedBox(
                  width: 72,
                  child: TextFormField(
                    initialValue: item.unit,
                    onChanged: onUnitChanged,
                    style: const TextStyle(fontSize: 13),
                    decoration: InputDecoration(
                      labelText: 'Unit',
                      labelStyle: TextStyle(
                          fontSize: 11, color: AppColors.mutedForeground),
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // Category dropdown
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: categories.contains(item.category)
                        ? item.category
                        : 'Other',
                    isDense: true,
                    style: const TextStyle(fontSize: 13, color: Colors.black87),
                    decoration: InputDecoration(
                      labelText: 'Category',
                      labelStyle: TextStyle(
                          fontSize: 11, color: AppColors.mutedForeground),
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            BorderSide(color: AppColors.border.withOpacity(0.5)),
                      ),
                    ),
                    items: categories
                        .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                        .toList(),
                    onChanged: (v) => v != null ? onCategoryChanged(v) : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Row 3: expiry date picker
            GestureDetector(
              onTap: onPickDate,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: AppColors.mintBg,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: AppColors.brandGreen.withOpacity(0.25)),
                ),
                child: Row(
                  children: [
                    Icon(LucideIcons.calendarDays,
                        size: 14, color: AppColors.brandGreen),
                    const SizedBox(width: 8),
                    Text(
                      'Expires: ${_fmtDate(item.expiryDate)}',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.brandGreen,
                      ),
                    ),
                    const Spacer(),
                    Icon(LucideIcons.pencil,
                        size: 12, color: AppColors.brandGreen),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}